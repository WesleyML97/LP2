﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarHorista = new System.Windows.Forms.Button();
            this.gpbTrabalhoHomeOffice = new System.Windows.Forms.GroupBox();
            this.rdbtnNao = new System.Windows.Forms.RadioButton();
            this.rdbtnSim = new System.Windows.Forms.RadioButton();
            this.lblSalarioPorHora = new System.Windows.Forms.Label();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.lblDiasFaltas = new System.Windows.Forms.Label();
            this.txtDiasFaltas = new System.Windows.Forms.TextBox();
            this.gpbTrabalhoHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInstanciarHorista
            // 
            this.btnInstanciarHorista.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnInstanciarHorista.Location = new System.Drawing.Point(302, 243);
            this.btnInstanciarHorista.Name = "btnInstanciarHorista";
            this.btnInstanciarHorista.Size = new System.Drawing.Size(168, 96);
            this.btnInstanciarHorista.TabIndex = 20;
            this.btnInstanciarHorista.Text = "Instanciar Horista";
            this.btnInstanciarHorista.UseVisualStyleBackColor = false;
            this.btnInstanciarHorista.Click += new System.EventHandler(this.BtnInstanciarHorista_Click);
            // 
            // gpbTrabalhoHomeOffice
            // 
            this.gpbTrabalhoHomeOffice.Controls.Add(this.rdbtnNao);
            this.gpbTrabalhoHomeOffice.Controls.Add(this.rdbtnSim);
            this.gpbTrabalhoHomeOffice.Location = new System.Drawing.Point(571, 28);
            this.gpbTrabalhoHomeOffice.Name = "gpbTrabalhoHomeOffice";
            this.gpbTrabalhoHomeOffice.Size = new System.Drawing.Size(200, 100);
            this.gpbTrabalhoHomeOffice.TabIndex = 19;
            this.gpbTrabalhoHomeOffice.TabStop = false;
            this.gpbTrabalhoHomeOffice.Text = "Trabalho em Home Office";
            // 
            // rdbtnNao
            // 
            this.rdbtnNao.AutoSize = true;
            this.rdbtnNao.Location = new System.Drawing.Point(19, 59);
            this.rdbtnNao.Name = "rdbtnNao";
            this.rdbtnNao.Size = new System.Drawing.Size(48, 17);
            this.rdbtnNao.TabIndex = 1;
            this.rdbtnNao.TabStop = true;
            this.rdbtnNao.Text = "NÃO";
            this.rdbtnNao.UseVisualStyleBackColor = true;
            // 
            // rdbtnSim
            // 
            this.rdbtnSim.AutoSize = true;
            this.rdbtnSim.Location = new System.Drawing.Point(19, 35);
            this.rdbtnSim.Name = "rdbtnSim";
            this.rdbtnSim.Size = new System.Drawing.Size(44, 17);
            this.rdbtnSim.TabIndex = 0;
            this.rdbtnSim.TabStop = true;
            this.rdbtnSim.Text = "SIM";
            this.rdbtnSim.UseVisualStyleBackColor = true;
            // 
            // lblSalarioPorHora
            // 
            this.lblSalarioPorHora.AutoSize = true;
            this.lblSalarioPorHora.Location = new System.Drawing.Point(42, 80);
            this.lblSalarioPorHora.Name = "lblSalarioPorHora";
            this.lblSalarioPorHora.Size = new System.Drawing.Size(83, 13);
            this.lblSalarioPorHora.TabIndex = 16;
            this.lblSalarioPorHora.Text = "Salário por Hora";
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(193, 77);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(183, 20);
            this.txtSalarioHora.TabIndex = 15;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(42, 54);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 14;
            this.lblNome.Text = "Nome";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(193, 51);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(183, 20);
            this.txtNome.TabIndex = 13;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(42, 28);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 12;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(193, 25);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(183, 20);
            this.txtMatricula.TabIndex = 11;
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Location = new System.Drawing.Point(42, 106);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(90, 13);
            this.lblNumeroHoras.TabIndex = 23;
            this.lblNumeroHoras.Text = "Número de Horas";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(193, 103);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(183, 20);
            this.txtHora.TabIndex = 22;
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(42, 132);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(144, 13);
            this.lblDataEntradaEmpresa.TabIndex = 25;
            this.lblDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(193, 129);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(183, 20);
            this.txtDataEntradaEmpresa.TabIndex = 24;
            // 
            // lblDiasFaltas
            // 
            this.lblDiasFaltas.AutoSize = true;
            this.lblDiasFaltas.Location = new System.Drawing.Point(42, 158);
            this.lblDiasFaltas.Name = "lblDiasFaltas";
            this.lblDiasFaltas.Size = new System.Drawing.Size(74, 13);
            this.lblDiasFaltas.TabIndex = 27;
            this.lblDiasFaltas.Text = "Dias de Faltas";
            // 
            // txtDiasFaltas
            // 
            this.txtDiasFaltas.Location = new System.Drawing.Point(193, 155);
            this.txtDiasFaltas.Name = "txtDiasFaltas";
            this.txtDiasFaltas.Size = new System.Drawing.Size(183, 20);
            this.txtDiasFaltas.TabIndex = 26;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDiasFaltas);
            this.Controls.Add(this.txtDiasFaltas);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.btnInstanciarHorista);
            this.Controls.Add(this.gpbTrabalhoHomeOffice);
            this.Controls.Add(this.lblSalarioPorHora);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gpbTrabalhoHomeOffice.ResumeLayout(false);
            this.gpbTrabalhoHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstanciarHorista;
        private System.Windows.Forms.GroupBox gpbTrabalhoHomeOffice;
        private System.Windows.Forms.RadioButton rdbtnNao;
        private System.Windows.Forms.RadioButton rdbtnSim;
        private System.Windows.Forms.Label lblSalarioPorHora;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.Label lblDiasFaltas;
        private System.Windows.Forms.TextBox txtDiasFaltas;
    }
}