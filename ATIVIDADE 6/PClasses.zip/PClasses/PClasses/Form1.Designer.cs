﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbotao01 = new System.Windows.Forms.Button();
            this.btnbotao02 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnbotao01
            // 
            this.btnbotao01.Location = new System.Drawing.Point(237, 160);
            this.btnbotao01.Name = "btnbotao01";
            this.btnbotao01.Size = new System.Drawing.Size(137, 89);
            this.btnbotao01.TabIndex = 0;
            this.btnbotao01.Text = "Mensalista";
            this.btnbotao01.UseVisualStyleBackColor = true;
            this.btnbotao01.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnbotao02
            // 
            this.btnbotao02.Location = new System.Drawing.Point(437, 160);
            this.btnbotao02.Name = "btnbotao02";
            this.btnbotao02.Size = new System.Drawing.Size(130, 89);
            this.btnbotao02.TabIndex = 1;
            this.btnbotao02.Text = "Horista";
            this.btnbotao02.UseVisualStyleBackColor = true;
            this.btnbotao02.Click += new System.EventHandler(this.Btnbotao02_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnbotao02);
            this.Controls.Add(this.btnbotao01);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnbotao01;
        private System.Windows.Forms.Button btnbotao02;
    }
}

