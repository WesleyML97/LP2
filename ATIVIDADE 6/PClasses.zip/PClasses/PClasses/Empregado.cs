﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract class Empregado
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        public int Matricula // propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public char Homeoffice
        {
            get { return homeOffice; }
            set { homeOffice = value; }

            // m´´etodo são ações/comportamentos
        }
        public string VerificaHome() //método
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado não trabalha em home office";
        }

        //virtual --> poder ser sobreescrito

        public virtual int TempoTrabalho()
        {
            // represanta um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days);
        }

        // deve ser implantado nas classes filhas (subclasses)


        public abstract double SalarioBruto(); // não preciso implementar

    }
}
