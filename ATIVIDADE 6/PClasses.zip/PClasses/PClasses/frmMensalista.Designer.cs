﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.lblDataEntradanaEmpresa = new System.Windows.Forms.Label();
            this.txtDataEntradanaEmpresa = new System.Windows.Forms.TextBox();
            this.gpbTrabalhoHomeOffice = new System.Windows.Forms.GroupBox();
            this.rdbtnSim = new System.Windows.Forms.RadioButton();
            this.rdbtnNao = new System.Windows.Forms.RadioButton();
            this.btnInstanciarMensalista = new System.Windows.Forms.Button();
            this.btnInstanciarMensalistaPassandoParametros = new System.Windows.Forms.Button();
            this.gpbTrabalhoHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(167, 57);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(33, 60);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(167, 92);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(273, 20);
            this.txtNome.TabIndex = 2;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(33, 95);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 3;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(33, 131);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioMensal.TabIndex = 5;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(167, 128);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(127, 20);
            this.txtSalarioMensal.TabIndex = 4;
            // 
            // lblDataEntradanaEmpresa
            // 
            this.lblDataEntradanaEmpresa.AutoSize = true;
            this.lblDataEntradanaEmpresa.Location = new System.Drawing.Point(33, 167);
            this.lblDataEntradanaEmpresa.Name = "lblDataEntradanaEmpresa";
            this.lblDataEntradanaEmpresa.Size = new System.Drawing.Size(129, 13);
            this.lblDataEntradanaEmpresa.TabIndex = 7;
            this.lblDataEntradanaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // txtDataEntradanaEmpresa
            // 
            this.txtDataEntradanaEmpresa.Location = new System.Drawing.Point(167, 164);
            this.txtDataEntradanaEmpresa.Name = "txtDataEntradanaEmpresa";
            this.txtDataEntradanaEmpresa.Size = new System.Drawing.Size(127, 20);
            this.txtDataEntradanaEmpresa.TabIndex = 6;
            // 
            // gpbTrabalhoHomeOffice
            // 
            this.gpbTrabalhoHomeOffice.Controls.Add(this.rdbtnNao);
            this.gpbTrabalhoHomeOffice.Controls.Add(this.rdbtnSim);
            this.gpbTrabalhoHomeOffice.Location = new System.Drawing.Point(558, 77);
            this.gpbTrabalhoHomeOffice.Name = "gpbTrabalhoHomeOffice";
            this.gpbTrabalhoHomeOffice.Size = new System.Drawing.Size(200, 100);
            this.gpbTrabalhoHomeOffice.TabIndex = 8;
            this.gpbTrabalhoHomeOffice.TabStop = false;
            this.gpbTrabalhoHomeOffice.Text = "Trabalho em Home Office";
            // 
            // rdbtnSim
            // 
            this.rdbtnSim.AutoSize = true;
            this.rdbtnSim.Location = new System.Drawing.Point(19, 35);
            this.rdbtnSim.Name = "rdbtnSim";
            this.rdbtnSim.Size = new System.Drawing.Size(44, 17);
            this.rdbtnSim.TabIndex = 0;
            this.rdbtnSim.TabStop = true;
            this.rdbtnSim.Text = "SIM";
            this.rdbtnSim.UseVisualStyleBackColor = true;
            // 
            // rdbtnNao
            // 
            this.rdbtnNao.AutoSize = true;
            this.rdbtnNao.Location = new System.Drawing.Point(19, 59);
            this.rdbtnNao.Name = "rdbtnNao";
            this.rdbtnNao.Size = new System.Drawing.Size(48, 17);
            this.rdbtnNao.TabIndex = 1;
            this.rdbtnNao.TabStop = true;
            this.rdbtnNao.Text = "NÃO";
            this.rdbtnNao.UseVisualStyleBackColor = true;
            // 
            // btnInstanciarMensalista
            // 
            this.btnInstanciarMensalista.Location = new System.Drawing.Point(198, 258);
            this.btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            this.btnInstanciarMensalista.Size = new System.Drawing.Size(132, 96);
            this.btnInstanciarMensalista.TabIndex = 9;
            this.btnInstanciarMensalista.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalista.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalista.Click += new System.EventHandler(this.BtnInstanciarMensalista_Click);
            // 
            // btnInstanciarMensalistaPassandoParametros
            // 
            this.btnInstanciarMensalistaPassandoParametros.Location = new System.Drawing.Point(426, 258);
            this.btnInstanciarMensalistaPassandoParametros.Name = "btnInstanciarMensalistaPassandoParametros";
            this.btnInstanciarMensalistaPassandoParametros.Size = new System.Drawing.Size(132, 96);
            this.btnInstanciarMensalistaPassandoParametros.TabIndex = 10;
            this.btnInstanciarMensalistaPassandoParametros.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstanciarMensalistaPassandoParametros.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstanciarMensalistaPassandoParametros);
            this.Controls.Add(this.btnInstanciarMensalista);
            this.Controls.Add(this.gpbTrabalhoHomeOffice);
            this.Controls.Add(this.lblDataEntradanaEmpresa);
            this.Controls.Add(this.txtDataEntradanaEmpresa);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.gpbTrabalhoHomeOffice.ResumeLayout(false);
            this.gpbTrabalhoHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.Label lblDataEntradanaEmpresa;
        private System.Windows.Forms.TextBox txtDataEntradanaEmpresa;
        private System.Windows.Forms.GroupBox gpbTrabalhoHomeOffice;
        private System.Windows.Forms.RadioButton rdbtnNao;
        private System.Windows.Forms.RadioButton rdbtnSim;
        private System.Windows.Forms.Button btnInstanciarMensalista;
        private System.Windows.Forms.Button btnInstanciarMensalistaPassandoParametros;
    }
}